package com.destroystokyo.paper.loottable;

import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

public class LootableInventoryReplenishEvent extends PlayerEvent implements Cancellable {

    private static final HandlerList HANDLER_LIST = new HandlerList();

    @NotNull private final LootableInventory inventory;
    private boolean cancelled;

    @ApiStatus.Internal
    public LootableInventoryReplenishEvent(@NotNull Player player, @NotNull LootableInventory inventory) {
        super(player);
        this.inventory = inventory;
    }

    @NotNull
    public LootableInventory getInventory() {
        return this.inventory;
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean cancel) {
        this.cancelled = cancel;
    }

    @NotNull
    public HandlerList getHandlers() {
        return HANDLER_LIST;
    }

    @NotNull
    public static HandlerList getHandlerList() {
        return HANDLER_LIST;
    }
}
